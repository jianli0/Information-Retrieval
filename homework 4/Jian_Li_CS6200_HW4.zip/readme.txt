1) environment:
	java: 
	java version "1.8.0_25" 

	python:
	Python 2.7.8
	(import matplotlib.pyplot as plt) to draw Zipfian Curve

2) run the code with:
InelliJ -> run HW4.main()

python sortedFreqList.py termFrequency.txt sortedFreqList.txt


2) files:
	readme.txt
	source code:
		sortedFreqList.py ( sort the term in frequency decreasing order and draw Zipfian Curve)
		src -> HW4.java (index and retrieval with simple analyzer)
	
	termFrequency.txt

	Zipfian Curve:
		zipf.png

	

	top100_Q_1.txt 
	top100_Q_2.txt 
	top100_Q_3.txt 
	top100_Q_4.txt

	comparingTable.txt

