1) environment:
	python:
	Python 2.7.8
	

2) run the code with:
python hw4.py results.txt relevance.txt

2) files:
	readme.txt
	relevance.txt (relevance document downloaded from given url)
	results.txt (query results from bm25 homework 3)
	
	hw5.py (source code)
	
	table.txt 
	(tables and 3 Values of P@20 and MAP all include in table.txt, P@20 and MAP are at end)

	(ATTENTION: I put all things in one table instead of 3 tables with adding an extra column queryID as the first column )

queryID		query
1 		portable operating systems 

2 		code optimization for space efficiency 

3 		parallel algorithms 
	

