instruction:

0)Finished in python 2.7:

1)packages used as below:

import urllib
import time
from bs4 import BeautifulSoup

2) The project takes about 8 minutes.

3) using “concordance” for focused crawling

4) Originally, after got two lists of urls, I wrote them into two .txt files; 
   Considering we don’t have same repository, in the code that I hand in,
   I print these urls to the screen. Please check them on your screen :)

5) The two lists of urls are in Q1.txt, Q2.txt separately 

6) The proportion of totals pages were retrieved by focused crawler for ‘concordance’ is:
   263 / 1000
   It is also printed to the screen at last.


