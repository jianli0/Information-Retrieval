instruction:


1) run the code with: python page_rank.py wt2g_inlinks.txt
		   or python page_rank_for_six_vertices.py six_vertices.txt 

2) the hand-in files are named the corresponding name .txt respectively.	
	1) in five files:
		six vertices values.txt
		perplexity.txt 
		top50 page rank.txt 
		top50 in link.txt
		proportions.txt
		
	2) answer to the final question is in Answer.txt




